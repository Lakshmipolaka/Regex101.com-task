
#python file

from flask import Flask, render_template,request
app=Flask(__name__)

@app.route('/')
def index():
    
    return render_template("index.html")
@app.route('/matching')
def matching():
    return render_template('matching.html',name=['in_1'],b='in_2'.count(i))
    






##################################
if __name__=='__main__':
    app.run(debug=True)